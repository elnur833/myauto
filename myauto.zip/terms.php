<?php
include_once 'template/header.php';
?>

<main class="main" role="main">
	<section class="terms_section full">
		<div class="container">
			<!---->
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-12">
						<ul class="breadcrumbs">
				            <li>
				                <a href="#">Ana səhifə</a>
				            </li>
				            <li>
				                <a href="#">İstifadə qaydaları</a>
				            </li>
				        </ul>
					</div>
				</div>
			</div>
			<!---->
			<div class="row">
				<div class="col-md-12 page_heading">
					<h2>İstifadə qaydaları</h2>
				</div>
				<div class="col-md-12 terms_and_c" >
					<h2>Qeydiyyat və Üzvlük Statusunun Şərtləri</h2>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>

					<h2>Xidmət haqqı və Komissiya</h2>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>

					<h2>Əməliyyatların etibarlılığı və Üzvün təhlükəsizliyi</h2>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>

					<h2>Məsuliyyətin limitləndirilməsi</h2>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.  </p>
				</div>
			</div>

		</div>
	</section>
</main>

<?php
include_once 'template/footer.php';
?>